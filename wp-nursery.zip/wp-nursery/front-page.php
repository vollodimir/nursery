<?php
/*
Template Name: Home Template
*/
?>

<?php get_header(); ?>
      <main>
        <section class="first-screen">
          <div class="first-screen__img">
            <img src="<?php nursery_check_asf('first_slide_image', '/wp-content/themes/wp-nursery/assets/img/first-screen.png') ?>" alt="<?php nursery_check_asf('first_slide_title', 'Quality Trees, Shrubs and More') ?>" />
          </div>
          <div class="first-screen__corner"></div>
          <div class="container">
            <div class="first-screen__body">
              <div class="first-screen__text">
                <h1><?php nursery_check_asf('first_slide_title', 'Quality Trees, Shrubs and More') ?></h1>
                <h3><?php nursery_check_asf('first_slide_subtitle', 'Family Owned <span>Since 1945') ?></span></h3>
                <?php nursery_check_asf('first_slide_description', '<p>
                  <strong>Stuart Nursery</strong> provides quality tree sales and installation
                  services to Parker and surrounding counties. We specialize in Texas native plants
                  for your residence, office or ranch.
                </p>
                <p>
                  Stop by and see our tremendous selection of native and traditional plants or
                  consult with one of our landscape experts.
                </p>') ?>
                <div class="first-screen__btn btn"><a href="<?php nursery_check_asf('all_buttons_link', '#') ?>"><?php nursery_check_asf('all_buttons_text', 'Request a Quote') ?></a></div>
              </div>
            </div>
          </div>
        </section>

        <section class="qualyty">
          <div class="container">
            <div class="qualyty__body">
                <?php
                  global $post;

                  $myposts = get_posts([ 
                    'numberposts' => -1,
                    'post_type'   => 'quality',
                  ]);

                  if( $myposts ){
                    foreach( $myposts as $post ){
                      setup_postdata( $post );
                      ?>
                        <div class="qualyty__ithem">
                          <img src="<?php 
                                      if(get_the_post_thumbnail_url()){
                                        the_post_thumbnail_url();
                                        } else {
                                          echo bloginfo('template_url'); ?>/assets/img/qualyty.png';<?php 
                                      }
                                    ?>" alt="<?php the_title(); ?>" />
                        </div>
                      <?php 
                    }
                  } else {
                    echo "<div  style='font-size:40px;line-height:80px;'>Qualities not found!</div><div> </div>";
                  }

                  wp_reset_postdata(); // Сбрасываем $post
                ?>
            </div>
          </div>
        </section>

        <section class="services">
          <div class="container">
            <div class="services__body">
              <div class="services__row">
                <h2><?php nursery_check_asf('services_title', 'Our Services') ?></h2>
                <p>
                <?php nursery_check_asf('services_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                  incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                  exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.') ?>
                  
                </p>
              </div>
              <div class="services__cards">
                <?php
                  global $post;

                  $myposts = get_posts([ 
                    'numberposts' => -1,
                    'post_type'   => 'our_services',
                  ]);

                  if( $myposts ){
                    foreach( $myposts as $post ){
                      setup_postdata( $post );
                      ?>
                        <div class="card">
                          <div class="card__body">
                            <div class="card__img">
                              <a href="<?php the_permalink(); ?>">
                                <img src="<?php 
                          if(get_the_post_thumbnail_url()){
                            the_post_thumbnail_url();
                            } else {
                              echo bloginfo('template_url'); ?>/assets/img/services/card_1.jpg';<?php 
                          }
                        ?>" alt="<?php the_title(); ?>" />
                              </a>
                            </div>
                            <div class="card__title">
                              <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </div>
                          </div>
                        </div>
                      <?php 
                    }
                  } else {
                    echo "<div style='font-size:40px; margin: 0 auto;line-height: normal;'>Services not found!</div><div> </div>";
                  }

                  wp_reset_postdata(); // Сбрасываем $post
                ?>
              </div>
            </div>
          </div>
        </section>

        <section class="video">
          <div class="container">
            <div class="video__body">
              <div class="video__text">
                <h2><?php nursery_check_asf('video_title', 'Stuart Nursery Tree Farm') ?></h2>
                <div class="video__description">
                <?php nursery_check_asf('video_description', '<p><span>Over 75 years</span>, Stuart Nursery has been growing trees and shrubs in
                    our own nurseries, so that we can provide a consistent supply of quality plants
                    to our customers.</p>
                    <p>Add a shady spot or a splash of color to your yard with a tree from our wide
                    selection of trees.</p>') ?>
                  
                </div>
                <div class="video__btn btn"><a href="<?php nursery_check_asf('all_buttons_link', '#') ?>"><?php nursery_check_asf('all_buttons_text', 'Request a Quote') ?></a></div>
              </div>
              <div class="video__player">
                <a href="javascript:PopUpShow()">
                  <img src="<?php nursery_check_asf('video_cover_image', '/wp-content/themes/wp-nursery/assets/img/video-placeholder.jpg') ?>" alt="<?php nursery_check_asf('video_title', 'Stuart Nursery Tree Farm') ?>" />
                  <span></span>
                </a>
                <div class="popup">
                  <div class="popup__body">
                    <div class="popup__bg">
                      <?php 
                        if(function_exists('get_field') && get_field('video_link')){
                          $video_url =  get_field('video_link'); 
                        } else {
                          $video_url =  'https://www.youtube.com/watch?v=S80ENu5K8Io';
                        }
                        echo wp_oembed_get($video_url); 
                      ?>
                      <a href="javascript:PopUpHide()">CLOSe</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section class="favorites">
          <div class="container-large">
            <div class="favorites__body">
              <h2><?php nursery_check_asf('favorites_tree_title', 'Some of Our Tree Favorites') ?></h2>
              <div class="sliders favorites__carousel">
                <?php
                    global $post;
                    $myposts = get_posts([ 
                      'numberposts' => -1,
                      'post_type'   => 'trees',
                    ]);

                    if( $myposts ){
                      foreach( $myposts as $post ){
                        setup_postdata( $post );
                        ?>
                          <div class="tree">
                            <div class="tree__body">
                              <h3><?php the_title(); ?></h3>
                              <div class="tree__hover">
                                <p>
                                <?php the_excerpt(); ?>
                                </p>

                                <div class="tree__price">
                                  <p>Price:</p>
                                  <p><?php 
                                      $price = get_post_meta( $post->ID, 'price', true );

                                      if ( $price ) {
                                        echo $price;
                                      } 
                                      ?>$</p>
                                </div>
                                <div class="tree__btn btn">
                                  <a href="<?php the_permalink(); ?>"><?php nursery_check_asf('favorites_tree_more', 'learn more') ?></a>
                                </div>
                              </div>
                              <div class="tree__img">
                                <img src="<?php 
                                              if(get_the_post_thumbnail_url()){
                                                the_post_thumbnail_url();
                                                } else {
                                                  echo bloginfo('template_url'); ?>/assets/img/carousel/carousel_1.png';<?php 
                                              }
                                          ?>" alt="<?php the_title(); ?>" />
                              </div>
                            </div>
                          </div>
                        <?php 
                      }
                    } else {
                      echo "<div style='font-size:40px; margin: 0 auto;line-height: normal;'>Favorite trees not found!</div><div> </div>";
                    }

                    wp_reset_postdata(); // Сбрасываем $post
                  ?>
              </div>
            </div>
          </div>
        </section>
 
        <section class="testimonials">
          <div class="container">
            <div class="testimonials__body">

              <?php
                    global $post;
                    $myposts = get_posts([ 
                      'numberposts' => -1,
                      'post_type'   => 'testimonials',
                    ]);

                    if( $myposts ){
                      foreach( $myposts as $post ){
                        setup_postdata( $post );
                        ?>
                          <div class="testimonial">
                            <div class="testimonial__body">
                              <div class="testimonial__head">
                                <div class="testimonial__img">
                                  <img src="<?php 
                                              if(get_the_post_thumbnail_url()){
                                                the_post_thumbnail_url();
                                                } else {
                                                  echo bloginfo('template_url'); ?>/assets/img/icon/default_user.svg';<?php 
                                              }
                                          ?>" alt="<?php the_title(); ?>" />
                                </div>

                                <div class="testimonial__name">
                                  <h3><?php the_title(); ?></h3>
                                  <div class="testimonial__stars"><?php 
                                      $stars = get_post_meta( $post->ID, 'stars', true );

                                      if ( $stars && $stars>0 && $stars<=5 ) {
                                        echo str_repeat('★', $stars);
                                        
                                      
                                      } else {
                                        echo '★★★★★';
                                      }
                                      ?> 
                                  </div>
                                </div>
                              </div>
                              <div class="testimonial__text">
                                <?php the_content(); ?>
                              </div> 
                            </div>
                          </div>
                        <?php 
                      }
                    } else {
                      echo "<div style='font-size:40px; margin: 0 auto;line-height: normal;'>Testimonials not found!</div>";
                    }

                    wp_reset_postdata(); // Сбрасываем $post
               ?>

              
            </div>
          </div>
        </section>

        <section class="subscribe">
          <div class="subscribe__body">
            <h3>
            <?php nursery_check_asf('subscribe_title', 'Enjoy our <span>promotions, discounts and tips</span> when you join our mailing list') ?>
            </h3>

            <!-- thenewsletterplugin.com/documentation/subscription/subscription-form-shortcodes/ -->
            <?php // echo do_shortcode('[newsletter_form form="1"]'); ?>
            <?php if (function_exists('newsletter_form')) {
                      newsletter_form('1');
                  } else {
                    ?>
                        <form>
                          <div class="subscribe__row">
                            <input type="email" placeholder="Enter Your Email" required />
                            <div class="subscribe__btn btn"><button>join the list</button></div>
                          </div>
                        </form>
            <?php
                  } ?>
          </div>
        </section>
      </main>
<?php get_footer(); ?>