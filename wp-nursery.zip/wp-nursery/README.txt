WP Nursery Theme Guide

	Steps:

	1. Install plugins (Plugins > Add New, search name plugins. Then install and activate.):
 
		- Advanced Custom Fields (https://wordpress.org/plugins/advanced-custom-fields/)
		- Newsletter (https://wordpress.org/plugins/newsletter/)
		

	2. Download the demo data in site: Import > WordPress > select the demo_data.xml file. 
	   The demo data is located in the theme directory called demo_data.xml

	3. Enjoy!
	

Theme site: https://github.com/vollodimir/nursery
