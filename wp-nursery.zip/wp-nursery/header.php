<!DOCTYPE html>
<html lang="<?php bloginfo('language'); ?>">
  <head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0" />
    <title><?php bloginfo('name'); ?></title>
    <meta name="description" content="<?php bloginfo('description'); ?>">

    <?php wp_head(); ?>
  </head>
  <body>
    <div class="wrapper">
      <header class="header" id="top">
        <div class="header__body">
          <div class="header__row container-large">
            <div class="header__adress">
              <?php nursery_check_asf('address', '2317 Fort Worth Hwy<br /> Weatherford, Texas 76087') ?>
            </div>
            <div class="header__logo">
                <?php 
                    if( get_custom_logo() ) {
                        the_custom_logo();
                      } else {
                        ?><a href="/"> <img src="<?php bloginfo('template_url'); ?>/assets/img/header_logo.svg" alt="<?php bloginfo('name'); ?>" /></a><?php
                      }
                ?>
              <p><?php nursery_check_asf('subtitle', 'WE SPECIALIZE IN TREE SALES & INSTAllaTION') ?></p>
            </div>
            <div class="header__work-time">
              <p><?php nursery_check_asf('address', 'Open Monday-Saturday<br /> 9 AM – 5 PM') ?>
                
              </p>
              <div class="telephone">
                <a href="tel:<?php nursery_check_asf('tel', '817-596-0003') ?>"><?php nursery_check_asf('tel', '817-596-0003') ?></a>
              </div>
            </div>
          </div>
          <!--fixed menu--> 
          <div class="header__bg-element">
            <div class="header__wrapper">
              <div class="header__container">
                <div class="header__navigation">
                  <input class="header__input" type="checkbox" />
                  <div class="header__lines"></div>
                  <nav class="header__all-menu">
                    <?php nursery_header_menu() ?>
                  </nav>
                  <div class="header__btn btn">
                    <a href="<?php nursery_check_asf('all_buttons_link', '#') ?>"><?php nursery_check_asf('all_buttons_text', 'Request a Quote') ?></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--fixed menu END-->
        </div>
      </header>

