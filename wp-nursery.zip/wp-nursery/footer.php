      <footer class="footer">
        <div class="container">
          <div class="footer__widgets">
            <div class="widget">
                <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-1') ) : ?>
                <?php endif; ?>
            </div>

            <div class="widget">

                <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-2') ) : ?>
                <?php endif; ?>    

            </div>

            <div class="widget">

                <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-3') ) : ?>
                <?php endif; ?>

            </div>

            <div class="widget">
              
                <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-4') ) : ?>
                <?php endif; ?>
              </div>
          
          </div>
        </div>
        <div class="footer__copyright">
          <div class="container">
            <div class="footer__row">
              <div class="footer__text">Copyright © 2022 <a href="#"><?php bloginfo('name'); ?></a>. All Right Reserved.</div>
                <?php nursery_footer_menu() ?>
            </div>
          </div>
        </div>
      </footer>
    </div>

    <div class="go-top">
      <a href="#top"> </a>
    </div>

    <?php wp_footer(); ?>
  </body>
</html>