<?php get_header(); ?>
<?php the_post(); ?>

      <main>
        <section class="blog">
          <div class="container">
            <div class="blog__body">
                <h1><?php the_title(); ?></h1>
                 
                  <div class="blog__entry">
                      <?php
                      if(get_the_post_thumbnail_url()){
                        ?><img src="<?php the_post_thumbnail_url();?>"><?php
                      }
                      the_content();
                    ?>
                  </div>
            </div>
          </div>
        </section>
      </main>

<?php get_footer(); ?>