<?php get_header(); ?>
<?php the_post(); ?>
      <main>
        <section class="services">
          <div class="container">
            <div class="services__body">
              <div class="services__row" style='flex-direction: column; align-items: center;'>
                <h2>404</h2>
                <p>Not Found!</p>
              </div>
            </div>
          </div>
        </section>
      </main>
<?php get_footer(); ?>