<?php
	add_action( 'wp_enqueue_scripts', function () {
	 //styles 
		wp_enqueue_style( 'normalize', get_template_directory_uri() . '/assets/css/normalize.css' );
		wp_enqueue_style( 'slick-theme', get_template_directory_uri() . '/assets/css/slick-theme.css' );
		wp_enqueue_style( 'slick', get_template_directory_uri() . '/assets/css/slick.css' );
		wp_enqueue_style( 'style', get_template_directory_uri() . '/assets/css/style.css' );
	 //scripts
		wp_enqueue_script( 'slick', get_template_directory_uri() . '/assets/js/slick.min.js', array('jquery'), false, true );
		wp_enqueue_script( 'main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), false, true );
		
	});





	//post type

	////qualyty
	function quality_create_post_type() {
		register_post_type( 'quality', array(
			'labels' => array(
				'menu_name' => 'Qualities',
				'singular_name' => 'Quality',
				'add_new' => 'Add quality'
			),
			'menu_position' => 5,
			'public' => true,
			'menu_icon' => 'dashicons-thumbs-up',
			'supports' => array('title', 'thumbnail' ),
		) );
	}

	add_action( 'init', 'quality_create_post_type' );
	


	////services
	function services_create_post_type() {
		register_post_type( 'our_services', array(
			'labels' => array(
				'menu_name' => 'Our Services',
				'singular_name' => 'Our Service',
				'add_new' => 'Add Service'
			),
			'menu_position' => 5,
			'has_archive' => true,
			'public' => true,
			'menu_icon' => 'dashicons-editor-table',
			'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'post-formats'),
			'revrite' => 'services'
		) );
	}

	add_action( 'init', 'services_create_post_type' );

	//favorites trees
	function trees_create_post_type() {
		register_post_type( 'trees', array(
			'labels' => array(
				'menu_name' => 'Trees',
				'singular_name' => 'Tree',
				'add_new' => 'Add Tree'
			),
			'menu_position' => 6,
			'public' => true,
			'has_archive' => true,
			'menu_icon' => 'dashicons-palmtree',
			'supports' => array('custom-fields', 'title', 'editor', 'thumbnail',  'excerpt', 'post-formats'),
		) );
	}

	add_action( 'init', 'trees_create_post_type' );

	//testimonials
	function testimonials_create_post_type() {
		register_post_type( 'testimonials', array(
			'labels' => array(
				'menu_name' => 'Testimonials',
				'singular_name' => 'Testimonial',
				'add_new' => 'Add testimonial'
			),
			'menu_position' => 7,
			'public' => true,
			'menu_icon' => 'dashicons-format-chat',
			'supports' => array('title', 'editor', 'custom-fields', 'thumbnail', 'post-formats'),
		) );
	}

	add_action( 'init', 'testimonials_create_post_type' );

	//enable standart custom fields
	add_filter('acf/settings/remove_wp_meta_box', '__return_false');


	//// register my menus
	function nursery_register_all_menus() {
		register_nav_menus(array(
			'header_menu' => 'Header menu',
			'footer_menu' => 'Footer menu'
			)
		);
	}
	add_action( 'init', 'nursery_register_all_menus' );
	
	//Theme Supports
	add_theme_support('menus');
	add_theme_support('post-thumbnails');
	add_theme_support('title-tag');
	add_theme_support('custom-logo');
	


	



	///header menu (add first image to home page)
	function nursery_header_menu () {
		$args = array(
			'theme_location' => 'header_menu',
			'menu_class' => 'header__menu',
			'container'       => 'ul', 
			'echo' => 0 
		  );
		$menu = wp_nav_menu( $args );
		$menu = preg_replace('~<li~', '<li><a href="/"><img src="/wp-content/themes/wp-nursery/assets/img/icon/menu_home.svg" alt="Home" /></a></li><li', $menu, 1 );
		echo $menu;
	}

	///footer menu
	function nursery_footer_menu () {
		$args = array( 
			'theme_location' => 'footer_menu',
			'menu_class' => 'footer__terms',
			'container_class' => 'footer__terms',
			'container'       => 'div', 
			'after' => ' | ',
			'items_wrap' => '%3$s',
			'echo' => 0
		  );
		$footer_menu = wp_nav_menu( $args );
		$footer_menu = preg_replace('~(<li[\s\S]*?>)|(<a[\s\S]*?/a>)|(</li>)~ui', '$2', $footer_menu);
		echo $footer_menu;
	}

	///check plugin activate 
	function nursery_check_asf($fielf_asf, $echo_text) {
		if(function_exists('get_field') && get_field($fielf_asf)){
			the_field($fielf_asf); 
		 } else {
			echo $echo_text; 
		}

	}

	///old widgets ON
	 add_filter( 'gutenberg_use_widgets_block_editor', '__return_false' );
	 add_filter( 'use_widgets_block_editor', '__return_false' );

	///add widgets area in footer
	function register_my_widgets(){
		register_sidebar(array(
				'name' => 'Footer Widget 1',
				'id' => 'footer-1',
				'description' => 'First widget area in footer',
				'before_widget' => '<div class="widget__body">',
				'after_widget' => '</div>',
				'before_title' => '<h3>',
				'after_title' => '</h3>',
			));
			register_sidebar(array(
				'name' => 'Footer Widget 2',
				'id' => 'footer-2',
				'description' => 'Second widget area in footer',
				'before_widget' => '<div class="widget__body">',
				'after_widget' => '</div>',
				'before_title' => '<h3>',
				'after_title' => '</h3>',
			));
			register_sidebar(array(
				'name' => 'Footer Widget 3',
				'id' => 'footer-3',
				'description' => 'Third widget area in footer',
				'before_widget' => '<div class="widget__body">',
				'after_widget' => '</div>',
				'before_title' => '<h3>',
				'after_title' => '</h3>',
			));
			register_sidebar(array(
				'name' => 'Footer Widget 4',
				'id' => 'footer-4',
				'description' => 'Fourth widget area in footer',
				'before_widget' => '<div class="widget__body widget__body--right">',
				'after_widget' => '</div>',
				'before_title' => '<h3>',
				'after_title' => '</h3>',
				));
	}
	add_action( 'widgets_init', 'register_my_widgets' );



?>


