<?php
/*
Template Name: Home posts
*/
 
get_header(); ?> 
      <main>
        <section class="blog">
          <div class="container">
            <div class="blog__body">
            <?php 
                if ( have_posts() ) : ?>
                <h1><?php single_cat_title( '', false ); ?></h1>
              <?php
                if ( category_description() ) : ?>
                <div class="blog__entry"><?php echo category_description(); ?></div>
                <?php endif; ?>
                <?php
                  while ( have_posts() ) : the_post(); ?>
                  <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                  <small><?php the_time('F jS, Y') ?> by <?php the_author_posts_link() ?></small>
                  <div class="blog__entry">
                    <?php the_content(); ?>
                  </div>
                <?php endwhile; 
                  else: ?>
                  <h2>Sorry, no posts matched your criteria.</h2>
                <?php endif; ?>
            </div>
          </div>
        </section>
      </main>
  <?php the_posts_pagination(); ?>
<?php get_footer(); ?>